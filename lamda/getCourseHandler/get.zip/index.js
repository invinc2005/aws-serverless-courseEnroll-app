const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");

const client = new DynamoDBClient({ region: "us-east-1" }); // change region if needed

exports.handler = async (event) => {
  // For testing, hardcoded value — later will come from event.pathParameters or query
  const courseId = "C001";

  const input = {
    TableName: "Courses",
    Key: {
      courseId: { S: courseId }
    }
  };

  try {
    const command = new GetItemCommand(input);
    const response = await client.send(command);

    const item = response.Item
      ? {
          courseId: response.Item.courseId.S,
          title: response.Item.title.S,
          description: response.Item.description.S,
          durationHours: Number(response.Item.durationHours.N),
          instructorName: response.Item.instructorName.S
        }
      : null;

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(item || { message: "Course not found" })
    };

  } catch (err) {
    console.error("Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};
